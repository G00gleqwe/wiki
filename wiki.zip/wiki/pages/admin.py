from django.contrib import admin
from .models import Page


admin.site.register(Page)


